odoo.define('pos_combo_pack.pos_product_pack_file', function (require) {
    "use strict";

    //    var ProductScreen = require('point_of_sale.ProductScreen');
    //    var PaymentScreen = require('point_of_sale.PaymentScreen');
    //    var models = require('point_of_sale.models');
    var { PosGlobalState, Orderline } = require('point_of_sale.models');
    //    var PopUpWidget = require('point_of_sale.AbstractAwaitablePopup');
    //    var Gui = require('point_of_sale.Gui');
    var _t  = require('web.core')._t;
    const { _lt } = require('@web/core/l10n/translation');
    //    var Model = this;
    var core = require('web.core');
    //    var QWeb = core.qweb;
    var utils = require('web.utils');
    var rpc = require('web.rpc');
    //    var round_di = utils.round_decimals;

    const { useListener } = require("@web/core/utils/hooks");
    const Registries = require('point_of_sale.Registries');
    var AbstractAwaitablePopup = require('point_of_sale.AbstractAwaitablePopup');
    const {Gui} = require("point_of_sale.Gui");
    const NumberBuffer = require('point_of_sale.NumberBuffer');

    // Load model and fields in py session.py

    // Own Pizza Popup is in separate File

    // Js Change for 16
    // ProductScreenWidget Widget -- Show PopUp
            //    const ProductScreenExtend = (ProductScreen) =>
            //        class extends ProductScreen {
            //                //            setup() {
            //                //            super.setup();
            //                //            useListener('click-product', this._clickProduct);
            //                //            }
            //            constructor() {
            //                super(...arguments);
            //            }
            //            get_product_by_ids(product_ids){
            //                var list = [];
            //                var length_of_ids = product_ids.length;
            //                if (product_ids) {
            //                    for (var i = 0, len = product_ids.length ; i < len; i++) {
            //                        list.push(this.pos.db.get_product_by_id(product_ids[i]));
            //                    }
            //                }
            //                return list;
            //            }
            //
            //            async _clickProduct(event){
            //            await super._clickProduct(...arguments)
            //                console.log("-----------doene  ");
            //                console.log("-----------doene  ");
            //                console.log("-----------doene  ");
            //                console.log("-----------doene  ");
            //                console.log("-----------doene  ");
                        //                var self = this
                        //                if (product.to_weight && this.pos.config.iface_electronic_scale) {
                        //                    // this.Gui.showPopup('scale',{product: product});
                        //                    Gui.showPopup('scale',{
                        //                    title: "Product",
                        //                    body: product,});
                        //                }
                        //                else {
                        //                    if (product.is_extra) {
                        //                        var data = [];
                        //                        _.each(self.pos.get('extra_product_topping'), function(extra){
                        //                            if (product.product_extra_id.indexOf(extra.id) >=0){
                        //                                data.push({'category':extra.product_categ_id[1],
                        //                                           'categ_id':extra.product_categ_id[0],
                        //                                           'multi_selection':extra.multi_selection,
                        //                                           'products':self.pos.db.get_product_by_category(extra.product_categ_id[0]),
                        //                                           'qty':extra.product_quantity
                        //                                })
                        //                            }
                        //                        });
                        //                        Gui.showPopup('scale',{title: title || _t("Product"),body: product,});
                        //                        Gui.showPopup('ownpizza',{'data':data, 'main_product':product.id});
                        //                    }
                        //                    else if (product.is_pack) {
                        //                        var data = [];
                        //                        var fix_pack_data = [];
                        //                        _.each(self.pos.get('pack_product'), function(pack){
                        //                            if( product.product_pack_id.indexOf(pack.id) >=0){
                        //                                data.push({'category':pack.product_categ_id,
                        //                                           'hnh':pack.hnh,
                        //                                           'required_item':pack.required_item,
                        //                                           'categ_id':pack.id,
                        //                                           'products':self.get_product_by_ids(pack.product_selection),
                        //                                           'qty':pack.product_quantity})
                        //                            }
                        //                        });
                        //                        _.each(self.pos.get('fix_pack_product'), function(pack){
                        //                            if( product.product_fix_pro_ids.indexOf(pack.id) >=0){
                        //                                fix_pack_data.push({'product':self.pos.db.get_product_by_id(pack.product_p_id[0]),
                        //                                    'qty': pack.product_quantity})
                        //                            }
                        //                        });
                        //                        Gui.show_popup('combopack',{'fix_pack_data': fix_pack_data, 'data': data, 'main_product':product.id });
                        //                    } else {
                        //                        this.pos.get_order().add_product(product);
                        //                    }
                        //                }
//            }
//        };
//    Registries.Component.extend(ProductScreen, ProductScreenExtend);
//    return ProductScreen;
    // End Js here

    // Js Change for 16
    // Order Line Widget
//    const PosOrderline = (Orderline) => class PosOrderline extends Orderline {
//        init_from_JSON(json) {
//            var self = this
//            if(json.is_pack){
//                this.pack_data = []
//                let combo_ids = json.combo_ids;
//                _.each( JSON.parse(combo_ids.replace(/&quot;/ig,'"')), function(item){
//                    item = item[2]
//                    self.pack_data.push({
//                        'product_id': self.pos.db.get_product_by_id(item.product_id),
//                        //'qty':item.qty * json.qty,
//                        'qty': item.qty,
//                        });
//                })
//            }
//            if(json.is_extra){
//                this.order_menu = json.order_menu;
//            }
//        }
//
//        export_as_JSON(){
//            var self = this;
//            var own_line = [];
//            var total_price = 0;
//            const json = _super_order_line.export_as_JSON.apply(this, arguments);
//            if(this.product.is_extra && this.own_data){
//                _.each(this.own_data, function(item){
//                    own_line.push([0, 0, {'product_id':item.product_id.id,
//                                          'name':item.product_id,
//                                          'qty':self.get_quantity(),
//                                          'price':item.price,
//                                          'price_subtotal_incl':0.0,
//                                          'price_subtotal':0.0,
//                                        }]);
//                    total_price += item.price;
//                });
//                json.order_menu = this.order_menu
//            }
//            if (this.product.is_extra){
//                json.price_unit = total_price;
//            }
//            json.price_unit = this.price;
//            json.is_extra = this.product.is_extra;
//            json.own_ids = this.product.is_extra ? own_line : [];
//            var combo_line = []
//            if(self.product.is_pack && self.pack_data){
//                _.each(self.pack_data, function(item){
//                    combo_line.push([0, 0, {
//                        'product_id':item.product_id.id,
//                        'name':item.product_id.display_name,
//                        // 'qty':item.qty * self.get_quantity(),
//                        'qty':item.qty,
//                        'price_subtotal_incl':0.0,
//                        'price_subtotal':0.0,
//                    }]);
//                })
//            }
//            json.is_pack = this.product.is_pack;
//            json.combo_ids = this.product.is_pack ? JSON.stringify(combo_line) : [];
//            return json;
//            }
//
//        clone(){
//            var orderline = super.clone(...arguments);
//            orderline.pack_data = this.pack_data;
//            orderline.combo_ids = this.combo_ids;
//            orderline.is_pack = this.is_pack;
//            orderline.is_extra = this.is_extra;
//            return orderline;
//        }
//    }
    // End Js here

    // Orderline Which show combo item and fixed after refresh screen
    const ComboItems = (Orderline) => class ComboItems extends Orderline {
        init_from_JSON (json){
            super.init_from_JSON(...arguments);
        	/*_super_order_line.init_from_JSON.apply(this,arguments);*/
        	var self = this
        	if(this.product.is_pack){
        		this.pack_data = []
        		let combo_ids = json.combo_ids;
        		_.each( JSON.parse(combo_ids.replace(/&quot;/ig,'"')), function(item){
        			item = item[2]
        			self.pack_data.push({
                        'product_id':self.pos.db.get_product_by_id(item.product_id),
                        'qty':item.qty,
                        });
                })
        	}

        	if(this.product.is_extra){
        		this.order_menu = json.order_menu
        	}
        }

        export_as_JSON (){
            var self = this;
            var own_line = [];
            var total_price = 0;
            var json = super.export_as_JSON(...arguments);;
            if(this.product.is_extra && this.product.own_data){
                _.each(this.own_data, function(item){
                    own_line.push([0, 0, {'product_id':item.product_id.id,
                                          'name':item.product_id,
                                          'qty':self.get_quantity(),
                                          'price':item.price,
                                          'price_subtotal_incl':0.0,
                                          'price_subtotal':0.0,
                                        }]);
                    total_price += item.price;
                });
                json.order_menu = this.order_menu
            }
            if (this.product.is_extra){
                json.price_unit = total_price;
            }
            json.price_unit = this.price;
            json.is_extra = this.product.is_extra;
            json.own_ids = this.product.is_extra ? own_line : [];
            var combo_line = []
            if(self.product.is_pack && self.pack_data){
                _.each(self.pack_data, function(item){
                    combo_line.push([0, 0, {
                                        'product_id':item.product_id.id,
                                        'name':item.product_id.display_name,
                                        // 'qty':item.qty * self.get_quantity(),
                                        'qty':item.qty,
                                        'price_subtotal_incl':0.0,
                                        'price_subtotal':0.0,
                                    }]);
                })
            }
            json.is_pack = this.product.is_pack;
            json.combo_ids = this.product.is_pack ? JSON.stringify(combo_line) : [];
            return json;
        }

        // TODO Clone function is not nesscessary here for time being
        //        clone(){
        //            var orderline = Orderline.create({}, {
        //            orderline.pack_data = this.pack_data;
        //            orderline.combo_ids = this.combo_ids;
        //            orderline.is_pack = this.is_pack;
        //            orderline.is_extra = this.is_extra;
        //            });
        //            return orderline;
        //        }
    }
    Registries.Model.extend(Orderline, ComboItems);


    // Js Change for 16
    // ComboPackWidget PopUp Widget
    class ComboPack extends AbstractAwaitablePopup {
        setup() {
            super.setup();
            var self = this;
            this.data = this.props.data;
            this.fix_pack_data = this.props.fix_pack_data;
            this.main_product = this.props.main_product;
            // this.renderElement();
            this.qty_multiplier = 1;
            // $('p.combo-title').text(this.env.pos.db.get_product_by_id(this.main_product).display_name);

                //            useListener('click-product', this.show);
                useListener('process_hnh', this.process_hnh);
                useListener('button-cancel', this.click_cancel);
                //            useListener('button-confirm', this.click_confirm);
                // useListener('add_qty', this.add_qty);
                //            useListener('minus', this.minus_qty);
        }

        //        async getPayload() {
        //            if (!this.currentOrder) {
        //                this.env.pos.add_new_order();
        //            }
        //            const product = this.props.main_product;
        //            const options = await this.env.pos.db.get_product_by_id(product);
        //            // Do not add product if options is undefined.
        //            if (!options) return;
        //            // Add the product after having the extra information.
        //            //            await this.addProduct(product, options);
        //            //            await this.currentOrder.add_product(product, options);;
        //            await this.env.pos.get_order().add_product(options, {});
        //            //            NumberBuffer.reset();
        //        }

        add_qty() {
            var $target = $('button.add_qty');
            this.qty_multiplier = +$($target).prev().val() + 1
            $($target).prev().val(this.qty_multiplier);
        }

        minus_qty() {
            var $target = $('button.minus');
            if ($($target).next().val() > 1) {
                this.qty_multiplier = +$($target).next().val() - 1
                $($target).next().val(this.qty_multiplier);
            }
        }

        process_hnh(event){
            var $target = event.target;
            if ($($target).hasClass('hnh')) {
                var $place = $($target).closest('td').prev('td');
                var $select = $place.find('select.product_combo_select');
                $select.attr('data-qty', '0.5')
                $select.prop('required',true);
                $($select).toggleClass('width-100 width-50')
                $place.empty().append($select.clone(true));
                $($target).find('i').toggleClass('fa-angle-up fa-angle-down');
                $($target).toggleClass('hnh highlight')
            } else {
                var $place = $($target).closest('td').prev('td');
                var $select = $place.find('select.product_combo_select').first();
                $select.attr('data-qty', '1')
                $select.prop('required',false);
                $($select).toggleClass('width-100 width-50')
                $place.empty().append($select.clone(true));
                $($target).find('i').toggleClass('fa-angle-down fa-angle-up');
                $($target).toggleClass('hnh highlight')
            }
        }

        click_cancel(){ this.env.posbus.trigger('close-popup', {popupId: this.props.id});}

        async confirm(event) {
    		var self = this;
            var validation = true;
            var pack_data = [];
    		var product = self.env.pos.db.get_product_by_id(parseInt($(".combo_product_id").data('product_id')));

            _.each($(".product_combo_select"), function(p_s){
                if ($(p_s).val() == "Select Your Food...." && $(p_s).attr('required') == 'required') {
                    $(p_s).css('color', 'red');
                    $(p_s).focus();
                    validation = false;
                    $('.flavour-warning').show()
                }
            });

            if (validation){
                _.each($(".product_combo_select"),function(p_s){
                    if ($(p_s).selected && $(p_s).attr('required') && $(p_s).val() == "Select Your Food...."){
                        $(p_s).focus();
                    }
                    if($(p_s).val() != "Select Your Food....") {
                        pack_data.push({"product_id":self.env.pos.db.get_product_by_id(parseInt($(p_s).val())),
                            'qty':$(p_s).attr('data-qty'),})
                    }

                });
                await rpc.query({
                    model: 'fix.product.pack',
                    method: 'search_read',
                    fields: ['id', 'product_p_id', 'product_quantity'],
                }).then(function (result) {
                   _.each(result, function(pack){
                    // if( product.product_fix_pro_ids.indexOf(pack.products.id) >=0){
                    if( product.product_fix_pro_ids.indexOf(pack.id) >=0){
                        pack_data.push({"product_id":self.env.pos.db.get_product_by_id(pack.product_p_id[0]),
                                        'qty':pack.product_quantity,
                        })
                    }
                });
                });
                _.each(this.env.pos.get_order().selected_orderline, function(pack){
                    //   if( product.product_fix_pro_ids.indexOf(pack.products.id) >=0){
                    if( product.product_fix_pro_ids.indexOf(pack) >=0){
                        pack_data.push({"product_id":self.env.pos.db.get_product_by_id(pack.product_p_id[0]),
                                        'qty':pack.product_quantity,
                        })
                    }
                });
                this.env.pos.get_order().add_product(product, {'merge':false, quantity: this.qty_multiplier});
                var current_order = this.env.pos.get_order().get_selected_orderline();
                if(current_order){
                    current_order.pack_data = pack_data;
                    current_order.set_selected();
                }
                this.click_cancel();
            }
        }
    }
    ComboPack.template = 'ComboPack';
    ComboPack.defaultProps = { cancelText: _lt('Cancel'),title: 'ComboPack', confirmText: _lt('Ok') };
    Registries.Component.add(ComboPack);
    // End Js here

    // Js Change for 16
    // Order Line Widget
//    const PosFinalizeOrder = (Orderline) =>
//        class PosFinalizeOrder extends Orderline {
//            constructor(obj, options) {
//                super(...arguments);
//                this.finalized_order = this.finalized_order || false;
//            }
//        //            initialize: function(attributes, options) {
//        //                _super_order.initialize.call(this,attr,options);
//        //                this.finalized_order = this.finalized_order || false;
//        //            }
//
//            export_as_JSON(){
//                var json = super.export_as_JSON.apply(this, arguments);
//                json.finalized_order = this.finalized_order;
//                return json;
//            }
//
//            init_from_JSON(json){
//                super.init_from_JSON.call(this, json);
//                this.finalized_order = json.finalized_order;
//            }
//        }
    // End Js here

     // Js Change for 16
    // PaymentScreen Widget
//    const PosMercuryPaymentScreen = (PaymentScreen) =>
//        class extends PaymentScreen {
//            finalize_validation(){
//                var order = this.pos.get_order();
//                order.finalized_order = true;
//                this._super();
//            }
//        };
    // End Js

});
